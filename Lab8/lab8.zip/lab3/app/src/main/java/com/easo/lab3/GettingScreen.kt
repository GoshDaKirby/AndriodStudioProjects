/*package com.easo.lab3

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun GreetingScreen(name: String) {
    val viewModel = VerseViewModel()
    viewModel.user.value = name
    viewModel.generateGreeting()
    viewModel.updateRandomVerse()

    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = viewModel.greetingMessage.value, fontSize = 20.sp, lineHeight = 40.sp)
        Text(text = viewModel.verseMessage.value, fontSize = 20.sp, lineHeight = 40.sp)
    }
}*/

package com.easo.lab3

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun GreetingScreen(name: String, viewModel: VerseViewModel = VerseViewModel()) {
    if (viewModel.isLoading.value) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else {
        Column(modifier = Modifier.padding(16.dp)) {
            viewModel.user.value = name
            viewModel.generateGreeting()
            viewModel.updateRandomVerse()

            Text(text = viewModel.greetingMessage.value, fontSize = 20.sp, lineHeight = 40.sp)
            Text(text = viewModel.verseMessage.value, fontSize = 20.sp, lineHeight = 40.sp)
        }
    }
}
