package com.easo.lab3

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun VerseListScreen() {
    val verses = VerseOfTheDay().getAllVersesList()

    LazyColumn {
        items(verses) { verse ->
            Text(text = "${verse.getBook()} ${verse.getChapter()}:${verse.getVerse()} - ${verse.getText()}")
        }
    }
}