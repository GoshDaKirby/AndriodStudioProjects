package com.easo.lab3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.easo.lab3.ui.theme.Lab3Theme

import java.util.Date
import java.text.SimpleDateFormat

import androidx.compose.foundation.layout.Column
import android.util.Log

import androidx.lifecycle.ViewModel

import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Lab3Theme {
                val navController = rememberNavController()
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NavigationComponent(navController = navController)
                }
            }
        }
    }
}

@Composable
fun NavigationComponent(navController: NavHostController) {
    NavHost(navController, startDestination = "main_screen") {
        composable("main_screen") {
            MainScreen(navController)
        }
        composable("verse_list_screen") {
            VerseListScreen()
        }
        // New destination that takes 'name' as a parameter
        composable("greeting_screen/{name}") { backStackEntry ->
            val name = backStackEntry.arguments?.getString("name") ?: ""
            GreetingScreen(name)
        }
    }
}

@Composable
fun MainScreen(navController: NavController) {
    val viewModel = VerseViewModel()
    var name by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Enter your name:") }
        )
        Button(onClick = {
            if (name.isNotBlank()) {
                navController.navigate("greeting_screen/$name")
            }
        }) {
            Text("Random Verse!")
        }

        Button(onClick = {
            navController.navigate("verse_list_screen")
        }) {
            Text(text = "Show All Verses")
        }
    }
}

fun GetVerse(): String {
    val rVerse = VerseOfTheDay()
    return rVerse.getRandomVerse()
}

/*  OLD CODE

@Composable
fun MainScreen(navController: NavController) {
    val viewModel = VerseViewModel()
    Column(modifier = Modifier.padding(16.dp)) {
        ShowVerse(viewModel)
        Button(onClick = {
            navController.navigate("verse_list_screen")
        }) {
            Text(text = "Show All Verses")
        }
    }
}

fun ShowVerse(viewModel: VerseViewModel) {
    Column {
        OutlinedTextField(
            value = viewModel.user.value,
            onValueChange = { viewModel.user.value = it },
            label = { Text("Enter your name:") }
        )
        Button(onClick = {
            viewModel.generateGreeting()
            viewModel.updateRandomVerse()
        }) {
            Text("Random Verse!")
        }
        Text(text = viewModel.greetingMessage.value, fontSize = 20.sp, lineHeight = 40.sp)
        Text(text = viewModel.verseMessage.value, fontSize = 20.sp, lineHeight = 40.sp)
    }
}


@Composable
fun NavigationComponent(navController: NavHostController) {
    NavHost(navController, startDestination = "main_screen") {
        composable("main_screen") {
            MainScreen(navController)
        }
        composable("verse_list_screen") {
            VerseListScreen()
        }
    }
}

@Preview
@Composable
fun VersePreview() {
    val viewModel = VerseViewModel()
    Lab3Theme {
        ShowVerse(viewModel)
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Lab3Theme {
        Greeting("Android")
    }
}

fun GetTime(user: String): String {
    val currentDate = Date()
    val dateFormat = SimpleDateFormat("HH")
    val currentHour = dateFormat.format(currentDate)
    val intHour = currentHour.toInt()
    return when (intHour) {
        in 3..11 -> "Good morning ${user}, here is your random Bible verse:"
        in 12..16 -> "Good afternoon ${user}, here is your random Bible verse:"
        in 17..23, in 0..2 -> "Good evening ${user}, here is your random Bible verse:"
        else -> "Invalid hour"
    }
}*/