package com.easo.lab3

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {
    private const val BASE_URL = "https://comp322-versedb-default-rtdb.firebaseio.com/"

    val verseApiService: VerseApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(VerseApiService::class.java)
    }
}
