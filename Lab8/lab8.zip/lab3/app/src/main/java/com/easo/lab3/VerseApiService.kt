package com.easo.lab3

import retrofit2.Response
import retrofit2.http.GET

interface VerseApiService {
    @GET("verses.json")
    suspend fun getVerses(): Response<List<BibleVerse>>
}

