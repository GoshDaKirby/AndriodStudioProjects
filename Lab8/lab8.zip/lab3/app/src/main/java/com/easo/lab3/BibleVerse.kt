package com.easo.lab3

//OLD CODE


import kotlin.random.Random
class BibleVerse {
    private var book: String = ""
    private var chapter: Int = 1
    private var verse: String = ""
    private var text: String = ""

    fun getBook(): String = book
    fun getChapter(): Int = chapter
    fun getVerse(): String = verse
    fun getText(): String = text

    fun setBook(book: String) {
        this.book = book
    }

    fun setChapter(chapter: Int) {
        if (chapter > 0) {
            this.chapter = chapter
        } else {
            throw IllegalArgumentException("Chapter must be greater than zero.")
        }
    }

    fun setVerse(verse: String) {
        if (verse != "") {
            this.verse = verse
        } else {
            throw IllegalArgumentException("Verse must be greater than zero.")
        }
    }

    fun setText(text: String) {
        this.text = text
    }
    fun printVerse() {
        println("$book $chapter:$verse - $text")
    }
    fun getBibleVerse(): String {
        return "$book $chapter:$verse - $text"
    }
}
/*
package com.easo.lab3

data class BibleVerse(
    val book: String = "",
    val chapter: Int = 0,
    val verse: Int = 0,
    val text: String = ""
)
*/