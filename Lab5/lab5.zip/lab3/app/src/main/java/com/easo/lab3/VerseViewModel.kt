package com.easo.lab3

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import java.text.SimpleDateFormat
import java.util.Date

class VerseViewModel : ViewModel() {
    var user = mutableStateOf("")
    var greetingMessage = mutableStateOf("")
    var verseMessage = mutableStateOf("")
    var timed = false
    init {
        updateRandomVerse()
    }

    fun updateRandomVerse() {
        if (timed) verseMessage.value = GetVerse() //doesn't generate verse until message is generated!
    }

    fun generateGreeting() {
        greetingMessage.value = GetTime(user.value)
    }

    private fun GetTime(user: String): String {
        timed = true
        val currentDate = Date()
        val dateFormat = SimpleDateFormat("HH")
        val currentHour = dateFormat.format(currentDate).toInt()
        return when (currentHour) {
            in 3..11 -> "Good morning $user, here is your random Bible verse:"
            in 12..16 -> "Good afternoon $user, here is your random Bible verse:"
            in 17..23, in 0..2 -> "Good evening $user, here is your random Bible verse:"
            else -> "Invalid hour"
        }
    }
}