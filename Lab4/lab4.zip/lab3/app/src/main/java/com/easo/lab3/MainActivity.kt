package com.easo.lab3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.easo.lab3.ui.theme.Lab3Theme

import java.util.Date
import java.text.SimpleDateFormat

import androidx.compose.foundation.layout.Column
import android.util.Log

import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Lab3Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    /*Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )*/
                    VersePreview()
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Lab3Theme {
        Greeting("Android")
    }
}

fun GetVerse(): String {
    val rVerse = VerseOfTheDay()
    return rVerse.getRandomVerse()
}

fun GetTime(user: String): String {
    val currentDate = Date()
    val dateFormat = SimpleDateFormat("HH")
    val currentHour = dateFormat.format(currentDate)
    val intHour = currentHour.toInt()
    return when (intHour) {
        in 3..11 -> "Good morning ${user}, here is your random Bible verse:"
        in 12..16 -> "Good afternoon ${user}, here is your random Bible verse:"
        in 17..23, in 0..2 -> "Good evening ${user}, here is your random Bible verse:"
        else -> "Invalid hour"
    }
}
@Composable
fun ShowVerse(modifier: Modifier = Modifier){
    var user by remember{mutableStateOf("user")}
    Column {
        OutlinedTextField(
            value = user,
            onValueChange = {user = it},
            label = {Text("Verse:")}
        )
        var message by remember{mutableStateOf("")}
        Button(onClick = {message = "${GetTime(user)}\n${GetVerse()}"}){
            Text("Random Verse!")
        }
        Text(text = message, modifier = modifier, fontSize = 20.sp, lineHeight = 40.sp)
    }

}
@Preview
@Composable
fun VersePreview() {
    Lab3Theme {
        ShowVerse()
    }
}