package com.easo.lab3

import android.content.Context
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun VerseListScreen(context: Context) {
    var verses by remember { mutableStateOf(listOf<BibleVerse>()) }

    LaunchedEffect(Unit) {
        val verseOfTheDay = VerseOfTheDay(context)
        verses = verseOfTheDay.getAllVersesList()
    }

    LazyColumn {
        items(verses) { verse ->
            Text(text = "${verse.getBook()} ${verse.getChapter()}:${verse.getVerse()} - ${verse.getText()}")
        }
    }
}