package com.easo.lab3

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface VerseDao {
    @Query("SELECT * FROM verses")
    fun getAllVerses(): List<VerseEntity>

    @Query("SELECT * FROM verses ORDER BY RANDOM() LIMIT 1")
    fun getRandomVerse(): VerseEntity

    @Insert
    fun insertVerses(verses: List<VerseEntity>)

    @Query("SELECT COUNT(*) FROM verses")
    fun getVerseCount(): Int
}