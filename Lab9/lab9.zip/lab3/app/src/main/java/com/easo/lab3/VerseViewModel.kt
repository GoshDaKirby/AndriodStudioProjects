package com.easo.lab3

import android.content.Context
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date

class VerseViewModel(private val context: Context) : ViewModel() {
    var user = mutableStateOf("")
    var greetingMessage = mutableStateOf("")
    var verseMessage = mutableStateOf("")
    var timed = false

    val verseOfTheDay = VerseOfTheDay(context)
    init {
        //updateRandomVerse()
        Log.d("MyTag", "View Model")
    }

    fun updateRandomVerse() {
        viewModelScope.launch {
            if (timed) {
                verseMessage.value = verseOfTheDay.getRandomVerse()
                //Log.d("MyTag", verseOfTheDay.gsid.toString())
            }
        }
    }

    fun generateGreeting() {
        timed = true
        greetingMessage.value = GetTime(user.value)
    }

    private fun GetTime(user: String): String {
        //timed = true
        val currentDate = Date()
        val dateFormat = SimpleDateFormat("HH")
        val currentHour = dateFormat.format(currentDate).toInt()
        return when (currentHour) {
            in 3..11 -> "Good morning $user, here is your random Bible verse:"
            in 12..16 -> "Good afternoon $user, here is your random Bible verse:"
            in 17..23, in 0..2 -> "Good evening $user, here is your random Bible verse:"
            else -> "Invalid hour"
        }
    }
}