package com.easo.lab3

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun GreetingScreen(name: String, viewModel: VerseViewModel) {
    Log.d("MyTag", "Getting")
    viewModel.user.value = name
    viewModel.generateGreeting()
    viewModel.updateRandomVerse()

    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = viewModel.greetingMessage.value, fontSize = 20.sp, lineHeight = 40.sp)
        Text(text = viewModel.verseMessage.value, fontSize = 20.sp, lineHeight = 40.sp)
    }
}