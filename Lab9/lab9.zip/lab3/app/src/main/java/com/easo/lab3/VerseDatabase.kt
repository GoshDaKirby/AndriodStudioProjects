package com.easo.lab3

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [VerseEntity::class], version = 1)
abstract class VerseDatabase : RoomDatabase() {
    abstract fun verseDao(): VerseDao

    companion object {
        @Volatile
        private var INSTANCE: VerseDatabase? = null

        fun getDatabase(context: Context): VerseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VerseDatabase::class.java,
                    "verse_database"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            INSTANCE?.let { database ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    val verseDao = database.verseDao()
                                    if (verseDao.getVerseCount() == 0) {
                                        val initialVerses = listOf(
                                            VerseEntity(book = "Proverbs", chapter = 3, verse = 5, text = "Trust in the Lord with all your heart and lean not on your own understanding;"),
                                            VerseEntity(book = "Romans", chapter = 8, verse = 28, text = "And we know that in all things God works for the good of those who love him, who have been called according to his purpose."),
                                            VerseEntity(book = "Philippians", chapter = 4, verse = 13, text = "I can do all this through him who gives me strength."),
                                            VerseEntity(book = "Psalm", chapter = 23, verse = 1, text = "The Lord is my shepherd, I lack nothing."),
                                            VerseEntity(book = "John", chapter = 3, verse = 16, text = "For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life."),
                                            VerseEntity(book = "Isaiah", chapter = 41, verse = 10, text = "So do not fear, for I am with you; do not be dismayed, for I am your God."),
                                            VerseEntity(book = "Matthew", chapter = 6, verse = 33, text = "But seek first his kingdom and his righteousness, and all these things will be given to you as well."),
                                            VerseEntity(book = "Jeremiah", chapter = 29, verse = 11, text = "\"For I know the plans I have for you,\" declares the Lord, \"plans to prosper you and not to harm you, plans to give you hope and a future.\""),
                                            VerseEntity(book = "1 Corinthians", chapter = 13, verse = 4, text = "Love is patient, love is kind. It does not envy, it does not boast, it is not proud."),
                                            VerseEntity(book = "Psalm", chapter = 46, verse = 1, text = "God is our refuge and strength, an ever-present help in trouble.")
                                        )
                                        verseDao.insertVerses(initialVerses)
                                    }
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}