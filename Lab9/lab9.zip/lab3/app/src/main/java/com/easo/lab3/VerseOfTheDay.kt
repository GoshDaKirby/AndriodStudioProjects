package com.easo.lab3

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class VerseOfTheDay(private val context: Context) {
    private val database = VerseDatabase.getDatabase(context)
    private val verseDao = database.verseDao()

    suspend fun getRandomVerse(): String {
        return withContext(Dispatchers.IO) {
            val randomVerse = verseDao.getRandomVerse()
            "${randomVerse.book} ${randomVerse.chapter}:${randomVerse.verse} - ${randomVerse.text}"
        }
    }

    suspend fun getAllVersesList(): List<BibleVerse> {
        return withContext(Dispatchers.IO) {
            verseDao.getAllVerses().map { entity ->
                BibleVerse().apply {
                    setBook(entity.book)
                    setChapter(entity.chapter)
                    setVerse(entity.verse)
                    setText(entity.text)
                }
            }
        }
    }
}